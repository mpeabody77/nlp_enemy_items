# ..............................................................................
# PROGRAM: 		1_Clean_Item_Data.R
#
# PURPOSE: 		Read item data and prepare it for LDA steps
#
# PROGRAMMER: J. B. Weir
#
# DATE: 		  April 8, 2022
#
# CHANGE LOG:
#
# DATE				  BY 		PURPOSE
# ..........		...		..........................................................
#
# ..............................................................................



# ..............................................................................
# Load packages ----
# ..............................................................................
library(doParallel) # For parallel processing
library(here) # To aid in the reading and writing of files
library(lubridate) # For handling date formats
library(openxlsx) # For eas ywriting of xlsx files
library(readxl) # For easy reading of xlsx files
library(SnowballC) # For stemming
library(textmineR)
library(themis)
library(tidymodels) # For setting up and running random forest (and other) models
library(tidytext) # For handling tokenization (plus other hand text tools)
library(tidyverse) # For general ease of data handling
library(tm) # for stripping punctuaiton, numbers, etc.
library(topicmodels)
library(vip)



# ..............................................................................
# Set paths ----
# ..............................................................................
path_root <- str_remove(here(), "Programs") # Where does this project live?
path_data <- paste0(path_root, "1_Data/")
path_LDA <- paste0(path_root, "2_LDA/")
path_plots_LDA <- paste0(path_LDA, "Plots/")
path_random_forest <- paste0(path_root, "3_Random_Forest/")
path_plots_random_forest <- paste0(path_random_forest, "Plots/")


# ..............................................................................
#  Read the Document-Text Matrix ----
# ..............................................................................
item_DTM <- read_rds(paste0(path_LDA, "item_DTM.rds"))



# ..............................................................................
#  Determine number of topics (k) ----
# ..............................................................................
# There is no right way to determine the number of topics in a data set, but we
# must specify something. What follows is one approach, whereby we use 5-fold
# cross validation to train/test the model given different numbers of topics.
# We'll assess some measures of fit, and select a reasonable number of topics
# for the final model


full_data  <- item_DTM # Make a copy of the DTM to pass to the model
n <- nrow(full_data) # How many documents in the set?

# 5-fold cross-validation, different numbers of topics 
folds <- 5 # Specify number of folds
splitfolds <- sample(1:folds, n, replace = TRUE) # Split the data into sets
candidate_k <- seq(from = 10, to = 150, by = 10) # What topic #s do we want to test?
alphaPrior <- 1/candidate_k # Rule of thumb: alpha starting value of 1/# of topics
estimation_method <- "Gibbs" # "Gibbs" or "VEM"
burnin = 1000
iter = 1000
keep = 50


# ..............................................................................
#  NOTE: This bit takes a while!  ----
#  For presentation, skip down to line 199
# ..............................................................................

# Set up a cluster for parallel processing
cluster <- makeCluster(detectCores(logical = TRUE) - 1) # Leave one core free
registerDoParallel(cluster)

# Load the needed R package on all the parallel sessions
clusterEvalQ(cluster, {
  library(topicmodels)
  library(ldatuning)
})

# export all the needed R objects to the parallel sessions
clusterExport(cluster, c("full_data", "burnin", "iter", "keep", "splitfolds", "folds", "candidate_k", "alphaPrior", "estimation_method"))


# we parallelize by the different number of topics.  A processor is allocated a value
# of k, and does the cross-validation serially. This is because it is assumed there
# are more candidate values of k than there are cross-validation folds, hence it
# will be more efficient to parallelise


system.time({
  results <- foreach(j = 1:length(candidate_k), .combine = rbind) %dopar%{
    k <- candidate_k[j]
    alphaPrior <- 1/k
    
    # results_1k <- matrix(0, nrow = folds, ncol = 2)
    results_1k <- matrix(0, nrow = folds, ncol = 6)
    # colnames(results_1k) <- c("Topics", "Perplexity")
    colnames(results_1k) <- c("Topics", "Split", "Perplexity", "Griffiths2004", "CaoJuan2009", "Arun2010")
    for(i in 1:folds){
      train_set <- full_data[splitfolds != i , ]
      valid_set <- full_data[splitfolds == i, ]
      
      
      # Here we check to see which estimation method we're trying
      if(estimation_method == "VEM"){
        
        # VEM approach
        fitted <- LDA(train_set,
                      k = candidate_k[j],
                      method = "VEM",
                      control = list(seed = 17,
                                     estimate.alpha = TRUE,
                                     alpha = alphaPrior,
                                     estimate.beta = TRUE),
                      mc.cores = 2L)
        results_1k[i,1:3] <- c(k, i, perplexity(fitted, newdata = valid_set))
        
        
        # VEM approach
        metrics <- FindTopicsNumber(train_set,
                                    topics = candidate_k[j],
                                    metrics = c("Griffiths2004", "CaoJuan2009", "Arun2010"),
                                    method = "VEM",
                                    control = list(seed = 17,
                                                   estimate.alpha = TRUE,
                                                   alpha = alphaPrior,
                                                   estimate.beta = TRUE),
                                    mc.cores = 2L
        )
        results_1k[i,5:6] <- c(as.matrix(metrics[1,2:3])) 
        
      } else {
        
        # Gibbs
        fitted <- LDA(train_set,
                      k = candidate_k[j],
                      method = "Gibbs",
                      control = list(seed = 17,
                                     burnin = burnin,
                                     iter = iter,
                                     keep = keep,
                                     alpha = alphaPrior),
                      mc.cores = 2L,
                      verbose = FALSE)
        
        results_1k[i,1:3] <- c(k, i, perplexity(fitted, newdata = valid_set))
        
        # Gibbs approach
        metrics <- FindTopicsNumber(train_set,
                                    topics = candidate_k[j],
                                    # metrics = c("Griffiths2004", "CaoJuan2009", "Arun2010"),
                                    metrics = c("Griffiths2004", "CaoJuan2009", "Arun2010"),
                                    method = "Gibbs",
                                    control = list(seed = 17,
                                                   burnin = burnin,
                                                   iter = iter,
                                                   keep = keep,
                                                   alpha = alphaPrior),
                                    mc.cores = 2L,
                                    verbose = FALSE)
        results_1k[i,4:6] <- c(as.matrix(metrics[1,2:4]))
        
      }
    }
    return(results_1k)
  }
})

stopCluster(cluster)

results_df <- as.data.frame(results)

if(estimation_method == "VEM"){
  saveRDS(results_df, file = paste0(path_LDA, "1_Fit_Statistics_VEM.RData")) # Save Fist Statistics
  write.xlsx(results_df, file = paste0(path_LDA, "1_Fit_Statistics_VEM.xlsx"))
} else {
  saveRDS(results_df, file = paste0(path_LDA, "1_Fit_Statistics_Gibbs.RData")) # Save Fist Statistics
  write.xlsx(results_df, file = paste0(path_LDA, "1_Fit_Statistics_Gibbs.xlsx"))
}

# ..............................................................................
#  Skip to this point!  ----
#  (If not assessing number of topics)
# ..............................................................................
results_df <- read_rds(paste0(path_LDA, "1_Fit_Statistics_Gibbs.RData")) %>% 
  print()




# ..............................................................................
#  Plot the fit measures  ----
#  To make a determination about number of topics, plot the fit measure
# ..............................................................................

# Griffiths is a metric we seek to maximize, but the rest we want to minimize
# Flip Griffiths so we can more clearly see a common low point @ ideal topic #
values <- results_df %>%
  mutate(Split = as.factor(Split),
         Griffiths2004 = Griffiths2004 * -1) %>% 
  print()

# Function for standardizing results
scaleThis <- function(x){
  (x - mean(x, na.rm = TRUE)) / sd(x, na.rm = TRUE)
}

# Standardize fit indices
values_standardized <- values %>%
  mutate(Griffiths2004 = scaleThis(Griffiths2004),
         Perplexity = scaleThis(Perplexity),
         CaoJuan2009 = scaleThis(CaoJuan2009),
         Arun2010 = scaleThis(Arun2010))


values_standardized_Optimum <- values_standardized %>%
  group_by(Topics) %>%
  summarise(Perplexity = mean(Perplexity),
            Griffiths2004 = mean(Griffiths2004),
            CaoJuan2009 = mean(CaoJuan2009),
            Arun2010 = mean(Arun2010)) %>%
  mutate(Optimum = ((Perplexity) + (CaoJuan2009) + (Arun2010) + Griffiths2004)/4,
         Split = as.factor("Mean")) %>%
  select(Topics, Split, Perplexity, CaoJuan2009, Arun2010, Griffiths2004, Optimum) %>%
  full_join(values_standardized)


# Go from wide to long
values_standardized_Optimum <- values_standardized_Optimum %>% 
  gather(Metric, Value, -Topics, -Split) %>%
  filter(Metric != "Split") %>%
  arrange(Topics, Metric, Split)

# Plot the output
p <- values_standardized_Optimum %>% 
  filter(Metric != "Optimum") %>%
  ggplot(aes_string(x = "Topics", y = "Value", group = "Metric")) + 
  geom_smooth(colour = "red") + 
  geom_point(aes_string(shape = "Metric"), size = 3, alpha = .5) + 
  guides(size = "none", shape = guide_legend(title = "Metrics:")) + 
  scale_x_continuous(breaks = c(seq(from = 0, to = 1500, by = 10))) + 
  labs(x = "Number of Topics", y = NULL) + 
  # facet_grid(Direction ~ .) + 
  theme_classic() %+replace% theme(panel.grid.major.y = element_blank(), 
                                   panel.grid.minor.y = element_blank(), panel.grid.major.x = element_line(colour = "grey70"), 
                                   panel.grid.minor.x = element_blank(), legend.key = element_blank(), 
                                   strip.text.y = element_text(angle = 90))
# Take a look at the plot
p

# Save the plot to disk
ggsave(paste0(path_plots_LDA, "FIT_NEW_GIBBS_2", ymd(Sys.Date()), "-", hour(Sys.time()), ".", minute(Sys.time()), ".", second(round(Sys.time(), 0)), ".png", sep = ""), width = 20, height = 10, units = "cm")

# ..............................................................................
# Using Gibbs sampling, let's call it 40 topics 
# (even though it's misbehaving with this small sample)
# ..............................................................................
