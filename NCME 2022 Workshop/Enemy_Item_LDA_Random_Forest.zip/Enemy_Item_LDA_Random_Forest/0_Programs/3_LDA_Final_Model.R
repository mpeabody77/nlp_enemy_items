# ..............................................................................
# PROGRAM: 		3_LDA_Final_Model.R
#
# PURPOSE: 		Read item data and prepare it for LDA steps
#
# PROGRAMMER: J. B. Weir
#
# DATE: 		  April 8, 2022
#
# CHANGE LOG:
#
# DATE				  BY 		PURPOSE
# ..........		...		..........................................................
#
# ..............................................................................



# ..............................................................................
# Load packages ----
# ..............................................................................
library(doParallel) # For parallel processing
library(here) # To aid in the reading and writing of files
library(lubridate) # For handling date formats
library(openxlsx) # For eas ywriting of xlsx files
library(readxl) # For easy reading of xlsx files
library(SnowballC) # For stemming
library(textmineR)
library(themis)
library(tidymodels) # For setting up and running random forest (and other) models
library(tidytext) # For handling tokenization (plus other hand text tools)
library(tidyverse) # For general ease of data handling
library(tm) # for stripping punctuaiton, numbers, etc.
library(topicmodels)
library(vip)


# ..............................................................................
# Set paths ----
# ..............................................................................
path_root <- str_remove(here(), "Programs") # Where does this project live?
path_data <- paste0(path_root, "1_Data/")
path_LDA <- paste0(path_root, "2_LDA/")
path_plots_LDA <- paste0(path_LDA, "Plots/")
path_random_forest <- paste0(path_root, "3_Random_Forest/")
path_plots_random_forest <- paste0(path_random_forest, "Plots/")


# ..............................................................................
#  Read the Document-Text Matrix ----
# ..............................................................................
item_DTM <- read_rds(paste0(path_LDA, "item_DTM.rds"))



# ..............................................................................
#  Fit the final LDA model ----
# ..............................................................................


# Create single LDA ----
burnin = 1000
iter = 1000
keep = 50
topics <- 40 # This is what we determined in the previous step
estimation_method <- c("Gibbs") # "Gibbs" or "VEM"

for(i in 1:length(topics)){
  timeStart <- Sys.time()
  alphaPrior <- round(1/topics[i], 3)
  cat("LDA with ", topics[i], " topics, alpha = ", alphaPrior, ", method = ", estimation_method, " starting.  Start time :   ", format(timeStart,'%H:%M:%S'), "\n", sep = "")
  
  if(estimation_method == "Gibbs"){
    
    # Gibbs approach
    itemLDA <- LDA(item_DTM,
                   k = topics[i],
                   method = "Gibbs",
                   control = list(seed = 17,
                                  burnin = burnin,
                                  iter = iter,
                                  keep = keep,
                                  alpha = alphaPrior),
                   mc.cores = 7L,
                   verbose = FALSE)
    
  } else {
    
    # VEM approach
    itemLDA <- LDA(item_DTM,
                   k = topics[i],
                   method = "VEM",
                   control = list(seed = 17,
                                  estimate.alpha = TRUE,
                                  alpha = alphaPrior,
                                  estimate.beta = TRUE),
                   mc.cores = 7L)
    
  }
  
  timeEnd <- Sys.time()
  elapsed <- timeEnd - timeStart
  if(!dir.exists(paste0(path_LDA))) dir.create(paste0(path_LDA), showWarnings = FALSE)
  saveRDS(itemLDA, file = paste0(path_LDA, "/itemLDA_", estimation_method, "_", topics[i], "K_", alphaPrior, "_Alpha.RData"))
  itemLDA
  cat("LDA with ", topics[i], " topics, alpha = ", alphaPrior, " complete.   Finish time : ",  format(timeEnd,'%H:%M:%S'), "\n", sep = "")
}



# ..............................................................................
#  Initial review of results ----
# ..............................................................................

# The beta matrix tells us how much each term contributes to each topic
itemTopics <- tidy(itemLDA, matrix = "beta")

# Get top 10 terms per topic
# This can provide some insight into what the topics are
item_top_terms <- itemTopics %>%
  arrange(topic, -beta) %>% 
  group_by(topic) %>%
  slice_head(n = 10) %>%
  ungroup() %>% 
  print()

# Plot top terms
item_top_terms  %>%
  mutate(term = reorder_within(term, beta, topic)) %>%
  ggplot(aes(term, beta, fill = factor(topic))) +
  geom_col(show.legend = FALSE) +
  facet_wrap(~ topic, ncol = 2, scales = "free") +
  coord_flip()
ggsave(paste0(path_plots_LDA, "topTerms_MATRIX.png"), width = 20, height = 80, units = "cm", dpi = 500, limitsize = FALSE)


# The gamma distribution tells us how much each topic contributes to each document/item
# Spread gamma values into a wide, document-by-topic matrix so we can calculate 
# Jensen-Shannon Divergence
itemGamma_wide <- tidy(itemLDA, matrix = "gamma") %>%
  spread(topic, gamma)




# Spread gamma values into a wide, document-by-topic matrix 
# so we can calculate Jensen-Shannon Divergence
itemGamma_wide <- itemGamma %>%
  spread(topic, gamma)

# Calculate Jensen-Shannon Divergence
jensen_shannon_divergence <- CalcJSDivergence(x =  as.matrix(itemGamma_wide[,1:topics[i]+1]), by_rows = TRUE)

# Some of these values can be ever so slightly negative (with Variational Expectation Maximization)
jensen_shannon_divergence[jensen_shannon_divergence < 0]
# So make those zero
jensen_shannon_divergence[jensen_shannon_divergence < 0] <- 0  # There are a few pairs (3-5?) that are infenentesimally negative.  Bump to 0.

# Take ste square root of the Divergence to get Jensen-Shannon Distance (this is the important bit)
jensen_shannon_distance <-as.data.frame(sqrt(jensen_shannon_divergence))

# In the next two steps, pull meaningful labels onto the JSD matrix
jensen_shannon_distance <- jensen_shannon_distance %>% 
  mutate(`Item ID A` = itemGamma_wide$document) %>% 
  select(`Item ID A`, everything())

colnames(jensen_shannon_distance)[2:ncol(jensen_shannon_distance)] <- c(itemGamma_wide$document)

# Pivot longer so we can begin setting up the pairwise data set that 
# we'll pass to the random forest model
itemDistanceLONG <- jensen_shannon_distance %>% 
  pivot_longer(!`Item ID A`, names_to = "Item ID B", values_to = "Distance")

# Now we clean up a little:
# 1) Remove pairs whee Jensen Shannon Distance = 0 (distance from itself)
# 2) Remove second of common comparisons: JSD(Item 1, Item 2) & JSD(Item 2, Item 1)

# Remove same-item pairs (This takes ~ 15 seconds)
itemDistanceLONG_Reduced <- itemDistanceLONG %>% 
  filter(`Item ID A` != `Item ID B`) %>% # Remove same-item pairs
  rowwise() %>% 
  mutate(pair_name = paste(sort(c(`Item ID A`, `Item ID B`)), collapse = "-")) %>% 
  distinct(pair_name, .keep_all = TRUE)


# Finally, we pull the metadata on for each item, and then we're ready for the Random Forest model
# Create a metadata-only data frame
metadata <- read_xlsx(paste0(path_data, "Sample_Items.xlsx")) %>%
  mutate(`Item ID` = as.character(`Item ID`),
         Metadata = as.factor(Metadata)) %>% 
  arrange(`Item ID`) %>% 
  select(`Item ID`, Metadata, Enemies) %>% 
  print()

# pull the metadata on for each item in the pair
final_LDA_output <- itemDistanceLONG_Reduced %>% 
  left_join(metadata, by = c("Item ID A" = "Item ID")) %>% 
  rename("Metadata A" = "Metadata",
         "Enemies A" = "Enemies") %>% 
  left_join(metadata, by = c("Item ID B" = "Item ID")) %>% 
  rename("Metadata B" = "Metadata",
         "Enemies B" = "Enemies") 

# Identify enemy pairs (This takes ~ 45 seconds; there's probably a better way to do this!)
final_LDA_output <- final_LDA_output %>%
  mutate(`Enemies A` = str_replace(`Enemies A`, " ", ""), # Remove whitespace in Enemy vector
         `Enemies B` = str_replace(`Enemies B`, " ", "")) %>% # Remove whitespace in Enemy vector
  # rowwise() %>% 
  mutate(Enemies = `Item ID B` %in% as.matrix(unlist(strsplit((`Enemies A`), ",", fixed = TRUE)))) %>% 
  print()

# And now clean up so we only retain what we'll need for the Random Forest Model
final_LDA_output <- final_LDA_output %>%
  select(`Item ID A`, `Item ID B`, pair_name, Enemies, Distance, `Metadata A`, `Metadata B`) %>% 
  print()

# Write the dataframe to disk (This is a big data set; it'll take a minute)
write_rds(final_LDA_output, paste0(path_LDA, "final_LDA_output.rds"))

