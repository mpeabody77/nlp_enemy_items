# ..............................................................................
# PROGRAM: 		4_Random_Forest_Model.R
#
# PURPOSE: 		Read item data and prepare it for LDA steps
#
# PROGRAMMER: J. B. Weir
#
# DATE: 		  April 8, 2022
#
# CHANGE LOG:
#
# DATE				  BY 		PURPOSE
# ..........		...		..........................................................
#
# ..............................................................................

# ..............................................................................
# NOTE: This setup is taken from Julia Silge's example. She's very good, and 
# it's worth following her work.
# 
# See https://juliasilge.com/blog/sf-trees-random-tuning/ for more information 
# and a very helpful video on tuning hyperparameters
# ..............................................................................

# ..............................................................................
# Load packages ----
# ..............................................................................
library(doParallel) # For parallel processing
library(here) # To aid in the reading and writing of files
library(lubridate) # For handling date formats
library(openxlsx) # For eas ywriting of xlsx files
library(readxl) # For easy reading of xlsx files
library(SnowballC) # For stemming
library(textmineR)
library(themis)
library(tidymodels) # For setting up and running random forest (and other) models
library(tidytext) # For handling tokenization (plus other hand text tools)
library(tidyverse) # For general ease of data handling
library(tm) # for stripping punctuaiton, numbers, etc.
library(topicmodels)
library(vip)


# ..............................................................................
# Set paths ----
# ..............................................................................
path_root <- str_remove(here(), "Programs") # Where does this project live?
path_data <- paste0(path_root, "1_Data/")
path_LDA <- paste0(path_root, "2_LDA/")
path_plots_LDA <- paste0(path_LDA, "Plots/")
path_random_forest <- paste0(path_root, "3_Random_Forest/")
path_plots_random_forest <- paste0(path_random_forest, "Plots/")



# ..............................................................................
# Read LDA output ----
# ..............................................................................
final_LDA_output <- read_rds(paste0(path_LDA, "final_LDA_output.rds")) %>% 
  mutate(Enemies = as.factor(Enemies)) %>% # The model will want this variable to be a factor
  print()



# ..............................................................................
# Setup for first tuning effort ----
# ..............................................................................
set.seed(123)
enemies_split <- initial_split(final_LDA_output, strata = Enemies)
enemies_train <- training(enemies_split)
enemies_test <- testing(enemies_split)

# Create the recipe for our model
enemy_recipe <- recipe(Enemies ~ ., data = enemies_train) %>% # Create the recipe for our model
  update_role(pair_name, new_role = "ID") %>%  # Let it know pair_name is a unique identifier
  step_rm( `Item ID A`, `Item ID B`) %>%
  step_downsample(Enemies, under_ratio = 100) # You will want to experiment with this

enepmy_pre <- prep(enemy_recipe)
juiced <- juice(enemy_prep) # Training set is ready to go

# Tune specifications
# min_n: An integer for the minimum number of data points in a node that are required for the node to be split further.
# mtry: An integer for the number of predictors that will be randomly sampled at each split when creating the tree models.
tune_spec <- rand_forest(
  mtry = tune(), 
  trees = 1000,
  min_n = tune()
) %>%
  set_mode("classification") %>%
  set_engine("ranger")

# Tune workflow
tune_wf <- workflow() %>%
  add_recipe(enemy_recipe) %>%
  add_model(tune_spec)


# Train the hyperparameters
set.seed(234)
enemies_folds <- vfold_cv(enemies_train, v = 5)

doParallel::registerDoParallel() # "partial argument match of 'along' to 'along.with'" is expected warning

# This takes some time (~ 10 min for this data set on my laptop)
set.seed(345)
tune_res <- tune_grid(
  tune_wf,
  resamples = enemies_folds,
  grid = 20
)

tune_res

# For the following plot:
#   min_n: An integer for the minimum number of data points in a node that are required for the node to be split further.
#   mtry: An integer for the number of predictors that will be randomly sampled at each split when creating the tree models.
initial_tune <- tune_res %>%
  collect_metrics() %>%
  filter(.metric == "roc_auc") %>%
  select(mean, min_n, mtry) %>%
  pivot_longer(min_n:mtry,
               values_to = "value",
               names_to = "parameter"
  ) %>%
  ggplot(aes(value, mean, color = parameter)) +
  geom_point(show.legend = FALSE) +
  facet_wrap(~parameter, scales = "free_x") +
  labs(x = NULL, y = "AUC")

# Save the plot to disk
ggsave(paste0(path_plots_random_forest, "1_Initial_Tune_Output_", ymd(Sys.Date()), "-", hour(Sys.time()), ".", minute(Sys.time()), ".", second(round(Sys.time(), 0)), ".png", sep = ""), width = 20, height = 10, units = "cm")



# Given feedback from the plots, min_n between 20 and 30 provides a better AUC
# and mtry = 2 is our best bet (this is a limitation of this sample dataset)
rf_grid <- grid_regular(
  mtry(range = c(1, 3)),
  min_n(range = c(20, 30)),
  levels = 5
)

rf_grid

# Now we pass the grid to tune a final time
# This takes some time (~ 5 min for this data set on my laptop)
set.seed(456)
regular_res <- tune_grid(
  tune_wf,
  resamples = enemies_folds,
  grid = rf_grid
)

regular_res
# write_rds(regular_res, paste0(path_random_forest, "regular_res.rds"))


# A final visual inspection to assess hyperparameters
final_tune <- regular_res %>%
  collect_metrics() %>%
  filter(.metric == "roc_auc") %>%
  mutate(min_n = factor(min_n)) %>%
  ggplot(aes(mtry, mean, color = min_n)) +
  geom_line(alpha = 0.5, size = 1.5) +
  geom_point() +
  labs(y = "AUC")
ggsave(paste0(path_plots_random_forest, "2_Final_Tune_Output_", ymd(Sys.Date()), "-", hour(Sys.time()), ".", minute(Sys.time()), ".", second(round(Sys.time(), 0)), ".png", sep = ""), width = 20, height = 10, units = "cm")


# Select the hyperparameters that provide the best AUC
# (Again, hefty grain of salt, given our sample dataset)
best_auc <- select_best(regular_res, "roc_auc")
best_auc

# Finalize the random forest model
final_rf <- finalize_model(
  tune_spec,
  best_auc
)

# min_n: An integer for the minimum number of data points in a node that are required for the node to be split further.
# mtry: An integer for the number of predictors that will be randomly sampled at each split when creating the tree models.
final_rf

# We can look at variable importance using the VIP package
# We should see that Jensen-Shannon Distance is an informative feature
# Other metadata features in your data set will also be informative
variable_importance <- final_rf %>%
  set_engine("ranger", importance = "permutation") %>%
  fit(Enemies ~ .,
      data = juice(enemy_prep) %>% select(-pair_name)
  ) %>%
  vip(geom = "point")
ggsave(paste0(path_plots_random_forest, "3_Variable_Importance_", ymd(Sys.Date()), "-", hour(Sys.time()), ".", minute(Sys.time()), ".", second(round(Sys.time(), 0)), ".png", sep = ""), width = 20, height = 10, units = "cm")

# Build out final work flow:
# We're now ready to fit a model on the entire training set
# and to test it against the test set
final_wf <- workflow() %>%
  add_recipe(enemy_recipe) %>%
  add_model(final_rf)

# Fit the model
# This won't take nearly as long because we're not using a v-fold approach, and we're
# fitting just one model
final_res <- final_wf %>%
  last_fit(enemies_split)

# Review fit:
# Note that Accuracy is very high; Vast majority of pairs are not enemies, 
# so our # of correct classifications/all classifications will be close to 1
final_res %>%
  collect_metrics()

# Sensitivity is a better measure of quality:
# Number of predicted enemies/True enemies
# Here's a confusion matrix
final_res %>%
  collect_predictions() %>%
  conf_mat(Enemies, .pred_class)
# We may be over-predicting enemy relationships, 
# but some of those are pairs that have never been reviewed by SMEs


