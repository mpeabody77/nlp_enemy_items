# ..............................................................................
# PROGRAM: 		1_Clean_Item_Data.R
#
# PURPOSE: 		Read item data and prepare it for LDA steps
#
# PROGRAMMER: J. B. Weir
#
# DATE: 		  April 8, 2022
#
# CHANGE LOG:
#
# DATE				  BY 		PURPOSE
# ..........		...		..........................................................
#
# ..............................................................................



# ..............................................................................
# Load packages ----
# ..............................................................................
library(doParallel) # For parallel processing
library(here) # To aid in the reading and writing of files
library(lubridate) # For handling date formats
library(openxlsx) # For eas ywriting of xlsx files
library(readxl) # For easy reading of xlsx files
library(SnowballC) # For stemming
library(textmineR)
library(themis)
library(tidymodels) # For setting up and running random forest (and other) models
library(tidytext) # For handling tokenization (plus other hand text tools)
library(tidyverse) # For general ease of data handling
library(tm) # for stripping punctuaiton, numbers, etc.
library(topicmodels)
library(vip)

# ..............................................................................
# Set paths ----
# ..............................................................................
path_root <- str_remove(here(), "Programs") # Where does this project live?
path_data <- paste0(path_root, "1_Data/")
path_LDA <- paste0(path_root, "2_LDA/")
path_plots_LDA <- paste0(path_LDA, "Plots/")
path_random_forest <- paste0(path_root, "3_Random_Forest/")
path_plots_random_forest <- paste0(path_random_forest, "Plots/")


# ..............................................................................
#  Read and clean the data ----
# ..............................................................................
sample_items <- read_xlsx(paste0(path_data, "Sample_Items.xlsx")) %>% 
  print()

# Combine the stem and the correct answer into a single string 
sample_items <- sample_items %>% 
  mutate(`Stem Answer String` = paste0(Stem, " ", `Correct Answer`)) %>% 
  select(`Item ID`, `Stem Answer String`, Metadata, Enemies)

# Make Metadata a factor
sample_items <- sample_items %>% 
  mutate(Metadata = as.factor(Metadata))

# Drop stop words (a, the, because, etc.)
# stop_words object combines the SMART, Snowball, and Onix stop word sets
item_text <- sample_items %>%
  mutate(`Item ID` = as.factor(`Item ID`)) %>%
  mutate(linenumber = row_number()) %>%
  unnest_tokens(word, `Stem Answer String`) %>%
  count(`Item ID`, word) %>%
  anti_join(stop_words) # Drop the stop words (a, the, because, etc.); The stop_words object combines the SMART, Snowball, and Onix stop word sets.

# Clean remaining words: stemming, punctuation, whitespace removal
item_text <- item_text %>%
  filter(word != "") %>%
  mutate(word = stripWhitespace(word)) %>% # Whitespace
  mutate(word = removePunctuation(word,
                                  preserve_intra_word_contractions = TRUE,
                                  preserve_intra_word_dases = TRUE)) %>% # Punctuation
  # mutate(word = hunspell_stem(word)) %>%
  mutate(word = wordStem(word)) # Porter stemming
  
 
# Create Document-Term Matrix
# This is what we'll pass to the model in the next steps
item_DTM <- item_text %>%
  cast_dtm(`Item ID`, word, n)

# In the following two lines we remove any documents with no words
# (Just in case we god carried away cleaning the data set)
rowTotals <- apply(item_DTM, 1, sum) # Find the # of words in each Document
item_DTM <- item_DTM[rowTotals > 0, ]  # Remove all documents without words

cat("itemText_DTM has", table(rowTotals < 1)[2], "empty documents as a result of stripping stop words.")

item_DTM$dimnames

# Write this to the LDA folder, and we'll pick up there in the next script
write_rds(item_DTM, paste0(path_LDA, "item_DTM.rds"))
